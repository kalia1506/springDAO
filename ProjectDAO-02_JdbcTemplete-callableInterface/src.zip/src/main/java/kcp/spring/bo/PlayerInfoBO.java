package kcp.spring.bo;

import lombok.Data;

@Data
public class PlayerInfoBO {
	private int pid;
	private String name;
	private String Player_type;
	private String country;
	private int salary;
	private String grade;
}
