package kcp.spring.dto;

import lombok.Data;

@Data
public class PlayerInfoDTO {
	private int pid;
	private String name;
	private String Player_type;
	private String country;
	private int salary;
	private String grade;
}
